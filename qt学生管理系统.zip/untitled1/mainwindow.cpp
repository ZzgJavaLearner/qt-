﻿#include "mainwindow.h"
#include "ui_mainwindow.h"
#include<QSqlDatabase>
#include<QSqlQuery>
#include<QMessageBox>
#include<loginedwindow.h>
MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
}

MainWindow::~MainWindow()
{
    delete ui;
}

//点击登录
void MainWindow::on_commitButtion_clicked()
{


    //检测username和password是否存在且正确
    QString username=ui->usernameText->text();
    QString password=ui->passwordText->text();
    QString sql=QString("select * from user where username='%1' and password='%2'")
            .arg(username)
            .arg(password);
    QSqlQuery sqlQuery;
    sqlQuery.exec(sql);
    bool key=false;
     QString userName;
     QString passWord;
    while(sqlQuery.next()){
        userName= sqlQuery.value(0).toString();
        passWord=sqlQuery.value(1).toString();
        if(username==userName&&password==passWord){
            key=true;
        }
    }
    if(key){
        //若用户存在，则登陆成功，跳转页面
        QMessageBox::information(NULL,"查询状态","用户登陆成功");
        this->hide();
        LoginedWindow *login=new LoginedWindow();
        login->show();
    }
    else{
        QMessageBox::information(NULL,"登录异常","用户名或者密码错误");
    }

}

void MainWindow::on_pushButton_clicked()
{

}
