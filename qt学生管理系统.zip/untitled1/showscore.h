#ifndef SHOWSCORE_H
#define SHOWSCORE_H

#include <QDialog>

namespace Ui {
class showScore;
}

class showScore : public QDialog
{
    Q_OBJECT

public:
    explicit showScore(QWidget *parent = nullptr);
    ~showScore();

private:
    Ui::showScore *ui;
};

#endif // SHOWSCORE_H
