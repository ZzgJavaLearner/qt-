#ifndef SHOWSCORES_H
#define SHOWSCORES_H

#include <QDialog>

namespace Ui {
class showScores;
}

class showScores : public QDialog
{
    Q_OBJECT

public:
    explicit showScores(QWidget *parent = nullptr);
    ~showScores();

private:
    Ui::showScores *ui;
};

#endif // SHOWSCORES_H
