#include "mainwindow.h"
#include<QSqlDatabase>
#include<QMessageBox>
#include <QApplication>

int main(int argc, char *argv[])
{

    QApplication a(argc, argv);
    Q_INIT_RESOURCE(images);
    MainWindow w;
    w.show();
    //连接mq
    QSqlDatabase db = QSqlDatabase::addDatabase("QODBC");
    db.setHostName("127.0.0.1"); //连接本地主机
    db.setPort(3306);
    db.setDatabaseName("qtdatabase");
    db.setUserName("root");
    db.setPassword("523619");
    bool ok = db.open();
    if (!ok){
    QMessageBox::warning(NULL,"连接提示", "连接数据库失败");
    }

    return a.exec();
}
