#ifndef LOGINEDWINDOW_H
#define LOGINEDWINDOW_H
#include <QMainWindow>

namespace Ui {
class LoginedWindow;
}

class LoginedWindow : public QMainWindow
{
    Q_OBJECT

public:
    static QString share_name;
    static QString share_id;
    static bool isname;
    Ui::LoginedWindow *ui;
    explicit LoginedWindow(QWidget *parent = nullptr);
    ~LoginedWindow();
private slots:

    void on_pushButton_clicked();

    void on_update_button_clicked();

    void on_addButton_clicked();

    void on_deleteButton_clicked();

    void on_jiangcheng_clicked();

    void on_zhiyuan_clicked();

    void on_byId_clicked();

    void on_byName_clicked();

    void on_showPutton_clicked();

private:
};

#endif // LOGINEDWINDOW_H
