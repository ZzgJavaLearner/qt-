#include "showscore.h"
#include "showscore.h"

showScore::showScore(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::showScore)
{
    ui->setupUi(this);
}

showScore::~showScore()
{
    delete ui;
}
