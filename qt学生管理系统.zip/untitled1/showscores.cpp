#include "showscores.h"
#include "ui_showscores.h"
#include<QSqlQuery>
showScores::showScores(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::showScores)
{
    ui->setupUi(this);
    QSqlQuery searchSqlQuery;
    searchSqlQuery.exec("SELECT * FROM student order by score+score2+score3+score4 desc");
    int row=0;

    ui->score_paihang->setColumnCount(7);
    ui->score_paihang->setHorizontalHeaderLabels(QStringList() << "姓名" << "学号" << "A成绩"<< "B成绩"<< "C成绩"<< "D成绩"<< "总成绩");
    while(searchSqlQuery.next()){
            QString stu_id=searchSqlQuery.value(0).toString();
            QString stu_sex=searchSqlQuery.value(1).toString();
            QString stu_age=searchSqlQuery.value(2).toString();
            QString stu_name=searchSqlQuery.value(3).toString();
            QString stu_score=searchSqlQuery.value(4).toString();
            QString stu_score2=searchSqlQuery.value(5).toString();
            QString stu_score3=searchSqlQuery.value(6).toString();
            QString stu_score4=searchSqlQuery.value(7).toString();
            int s1=searchSqlQuery.value(5).toInt();
            int s2=searchSqlQuery.value(6).toInt();
            int s3=searchSqlQuery.value(7).toInt();
            int s4=searchSqlQuery.value(4).toInt();
            int s5=s1+s2+s3+s4;
            QString stu_score5=QString::number(s5);
            ui->score_paihang->insertRow(row);
            ui->score_paihang->setItem(row,0,new QTableWidgetItem(stu_name));

            ui->score_paihang->setItem(row,1,new QTableWidgetItem(stu_id));
            ui->score_paihang->setItem(row,2,new QTableWidgetItem(stu_score));
            ui->score_paihang->setItem(row,3,new QTableWidgetItem(stu_score2));
            ui->score_paihang->setItem(row,4,new QTableWidgetItem(stu_score3));
            ui->score_paihang->setItem(row,5,new QTableWidgetItem(stu_score4));
            ui->score_paihang->setItem(row,6,new QTableWidgetItem(stu_score5));

            row++;
        }

    }



showScores::~showScores()
{
    delete ui;
}
