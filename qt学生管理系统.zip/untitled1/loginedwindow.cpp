#include "loginedwindow.h"
#include "ui_loginedwindow.h"
#include <QProcess>
#include<QSqlDatabase>
#include<QSqlQuery>
#include<QMessageBox>
#include<loginedwindow.h>
#include<showscores.h>
LoginedWindow::LoginedWindow(QWidget *parent) :

    QMainWindow(parent),
    ui(new Ui::LoginedWindow)
{
    ui->setupUi(this);
    ui->time->setDateTime(QDateTime::currentDateTime());

}

LoginedWindow::~LoginedWindow()
{
    delete ui;
}
QString LoginedWindow::share_id=NULL;
QString LoginedWindow::share_name=NULL;
bool LoginedWindow::isname=false;
void LoginedWindow::on_pushButton_clicked()
{
//判断按钮是id还是name
    if(isname){
        QString name=ui->searchText->text();
        QString searchSql=QString("select * from student where name='%1' ")
                .arg(name);
       QSqlQuery searchSqlQuery;
       searchSqlQuery.exec(searchSql);

       QString stu_name;
       bool key=true;
       while(searchSqlQuery.next()){
           stu_name=searchSqlQuery.value(3).toString();

           if(stu_name==name){
               key=false;
               LoginedWindow::share_name=stu_name;
               QString stu_sex=searchSqlQuery.value(1).toString();
               QString stu_age=searchSqlQuery.value(2).toString();
               QString stu_id=searchSqlQuery.value(0).toString();
               int s1=searchSqlQuery.value(4).toInt();
               int s2=searchSqlQuery.value(5).toInt();
               int s3=searchSqlQuery.value(6).toInt();
               int s4=searchSqlQuery.value(7).toInt();
               int s5=s1+s2+s3+s4;
               QString stu_score=searchSqlQuery.value(4).toString();
               QString stu_score2=searchSqlQuery.value(5).toString();
               QString stu_score3=searchSqlQuery.value(6).toString();
               QString stu_score4=searchSqlQuery.value(7).toString();
               QString stu_score5=QString(s5);
               ui->id->setText(stu_id);
               ui->age->setText(stu_age);
               ui->name->setText(stu_name);
               ui->score->setText(stu_score);
               ui->sex->setText(stu_sex);
               ui->score_2->setText(stu_score2);
               ui->score_3->setText(stu_score3);
               ui->score_4->setText(stu_score4);
               ui->score_5->setText(stu_score5);
               break;
           }

       }
       if(key){
           QMessageBox::information(NULL,"提示","没有叫该名字的学生");
           ui->id->setText("");
           ui->age->setText("");
           ui->name->setText("");
           ui->score->setText("");
           ui->sex->setText("");
           ui->score_2->setText("");
           ui->score_3->setText("");
           ui->score_4->setText("");
           ui->score_5->setText("");
       }
    }else{
    QString id=ui->searchText->text();
    QString searchSql=QString("select * from student where id='%1' ")
            .arg(id);
   QSqlQuery searchSqlQuery;
   searchSqlQuery.exec(searchSql);

   QString stu_id;
   bool key=true;
   while(searchSqlQuery.next()){
       stu_id=searchSqlQuery.value(0).toString();

       if(stu_id==id){
           key=false;
           LoginedWindow::share_id=stu_id;
           QString stu_sex=searchSqlQuery.value(1).toString();
           QString stu_age=searchSqlQuery.value(2).toString();
           QString stu_name=searchSqlQuery.value(3).toString();
           QString stu_score=searchSqlQuery.value(4).toString();
           int s1=searchSqlQuery.value(5).toInt();
           int s2=searchSqlQuery.value(6).toInt();
           int s3=searchSqlQuery.value(7).toInt();
           int s4=searchSqlQuery.value(4).toInt();
           int s5=s1+s2+s3+s4;

           QString stu_score2=searchSqlQuery.value(5).toString();
           QString stu_score3=searchSqlQuery.value(6).toString();
           QString stu_score4=searchSqlQuery.value(7).toString();
           QString stu_score5=QString::number(s5);
           ui->id->setText(stu_id);
           ui->age->setText(stu_age);
           ui->name->setText(stu_name);
           ui->score->setText(stu_score);
           ui->sex->setText(stu_sex);
           ui->score_2->setText(stu_score2);
           ui->score_3->setText(stu_score3);
           ui->score_4->setText(stu_score4);
           ui->score_5->setText(stu_score5);
           break;
       }

   }
   if(key){
       QMessageBox::information(NULL,"提示","没有该学号的学生");
       ui->id->setText("");
       ui->age->setText("");
       ui->name->setText("");
       ui->score->setText("");
       ui->sex->setText("");
       ui->score_2->setText("");
       ui->score_3->setText("");
       ui->score_4->setText("");
       ui->score_5->setText("");
   }
    }
}

void LoginedWindow::on_update_button_clicked()
{
   QString id=LoginedWindow::share_id;
 /*  if(ui->id->toPlainText()!=id)
   {
       QMessageBox::information(NULL,"警告","请勿修改学号");
       return;
   }*/

   if(ui->id==NULL){
       QMessageBox::information(NULL,"提示","请先找到学生");
   }else{
//change_score *change=new change_score();
       QString changeSql;
//change->show();
       if(!isname){

          changeSql=  QString("update student set sex='%1',name='%2',score=%3,age=%4,score2=%5,score3=%6,score4=%7 where id='%8'")
            .arg(ui->sex->toPlainText())
            .arg(ui->name->toPlainText())
            .arg(ui->score->toPlainText().toInt())
            .arg(ui->age->toPlainText().toInt())

                  .arg(ui->score_2->toPlainText().toInt())
                  .arg(ui->score_3->toPlainText().toInt())
                  .arg(ui->score_4->toPlainText().toInt())
                  .arg(ui->id->toPlainText())
                  ;
       }else{
           changeSql=
                   QString("update student set sex='%1',score=%3,age=%4,id=%5,score2=%6,score3=%7,score4=%8 where name='%2'")
                   .arg(ui->sex->toPlainText())
                   .arg(ui->name->toPlainText())
                   .arg(ui->score->toPlainText().toInt())
                   .arg(ui->age->toPlainText().toInt())
                   .arg(ui->id->toPlainText())
                   .arg(ui->score_2->toPlainText().toInt())
                   .arg(ui->score_3->toPlainText().toInt())
                   .arg(ui->score_4->toPlainText().toInt())
                   ;
       }
    QSqlQuery sql;
    if(sql.exec(changeSql)){
        QMessageBox::information(NULL,"提示","修改成功");
    }else{
        QMessageBox::information(NULL,"提示","修改失败");
    }

   }
}


void LoginedWindow::on_addButton_clicked()
{
    QString addSql=
            QString("insert into student(sex,name,score,age,id,score2,score3,score4) value('%1','%2',%3,%4,'%5',%6,%7,%8)")
            .arg(ui->sex->toPlainText())
            .arg(ui->name->toPlainText())
            .arg(ui->score->toPlainText().toInt())
            .arg(ui->age->toPlainText().toInt())
            .arg(ui->id->toPlainText())
            .arg(ui->score_2->toPlainText().toInt())
            .arg(ui->score_3->toPlainText().toInt())
            .arg(ui->score_4->toPlainText().toInt())
            ;
    QSqlQuery SQL;
    if(SQL.exec(addSql)){
            QMessageBox::information(NULL,"提示","添加成功");
    }else{
        QMessageBox::information(NULL,"提示","添加失败");
    }

}

void LoginedWindow::on_deleteButton_clicked()
{
    QString deleteSql;
    QSqlQuery SQL;
    if(!isname){
     deleteSql=
            QString("delete from student where id='%1'")
            .arg(ui->id->toPlainText());


    }else{
        deleteSql=
               QString("delete from student where name='%1'")
               .arg(ui->name->toPlainText());
    }
    if(SQL.exec(deleteSql)){
            QMessageBox::information(NULL,"提示","删除成功");
    }else{
        QMessageBox::information    (NULL,"提示","删除失败");
    }
}


void LoginedWindow::on_byId_clicked()
{
    isname=false;
}

void LoginedWindow::on_byName_clicked()
{
    isname=true;
}

void LoginedWindow::on_showPutton_clicked()
{

showScores *s=new showScores();
s->show();
}
void LoginedWindow::on_jiangcheng_clicked(){

}
void LoginedWindow::on_zhiyuan_clicked(){

}
