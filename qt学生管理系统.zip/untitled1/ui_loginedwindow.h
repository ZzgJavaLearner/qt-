/********************************************************************************
** Form generated from reading UI file 'loginedwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.14.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_LOGINEDWINDOW_H
#define UI_LOGINEDWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDateTimeEdit>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QRadioButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QTextEdit>
#include <QtWidgets/QToolBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_LoginedWindow
{
public:
    QWidget *centralwidget;
    QLabel *label;
    QLineEdit *searchText;
    QPushButton *pushButton;
    QPushButton *update_button;
    QTextEdit *name;
    QTextEdit *sex;
    QTextEdit *id;
    QTextEdit *age;
    QTextEdit *score;
    QLabel *label_3;
    QLabel *label_4;
    QLabel *label_5;
    QLabel *label_6;
    QLabel *label_7;
    QPushButton *addButton;
    QPushButton *deleteButton;
    QRadioButton *byId;
    QRadioButton *byName;
    QLabel *label_2;
    QPushButton *showPutton;
    QLabel *label_8;
    QTextEdit *score_2;
    QLabel *label_9;
    QTextEdit *score_3;
    QLabel *label_10;
    QTextEdit *score_4;
    QLabel *label_11;
    QTextEdit *score_5;
    QDateTimeEdit *time;
    QMenuBar *menubar;
    QStatusBar *statusbar;
    QToolBar *toolBar;

    void setupUi(QMainWindow *LoginedWindow)
    {
        if (LoginedWindow->objectName().isEmpty())
            LoginedWindow->setObjectName(QString::fromUtf8("LoginedWindow"));
        LoginedWindow->resize(780, 932);
        LoginedWindow->setStyleSheet(QString::fromUtf8("color: rgb(84, 92, 255);\n"
"background-image: url(:/new/prefix1/2f4ef1a7f57749bf90acf1cb8be1bf13.jpg);"));
        centralwidget = new QWidget(LoginedWindow);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        label = new QLabel(centralwidget);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(30, 30, 791, 81));
        label->setStyleSheet(QString::fromUtf8("font: 36pt \"Agency FB\";"));
        searchText = new QLineEdit(centralwidget);
        searchText->setObjectName(QString::fromUtf8("searchText"));
        searchText->setGeometry(QRect(480, 150, 161, 41));
        pushButton = new QPushButton(centralwidget);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        pushButton->setGeometry(QRect(660, 150, 101, 41));
        pushButton->setStyleSheet(QString::fromUtf8("font: 14pt \"Agency FB\";"));
        update_button = new QPushButton(centralwidget);
        update_button->setObjectName(QString::fromUtf8("update_button"));
        update_button->setGeometry(QRect(390, 220, 111, 41));
        update_button->setStyleSheet(QString::fromUtf8("font: 20pt \"Agency FB\";\n"
"font: 14pt \"Agency FB\";"));
        name = new QTextEdit(centralwidget);
        name->setObjectName(QString::fromUtf8("name"));
        name->setGeometry(QRect(220, 320, 201, 31));
        sex = new QTextEdit(centralwidget);
        sex->setObjectName(QString::fromUtf8("sex"));
        sex->setGeometry(QRect(220, 370, 201, 31));
        id = new QTextEdit(centralwidget);
        id->setObjectName(QString::fromUtf8("id"));
        id->setGeometry(QRect(220, 420, 201, 31));
        age = new QTextEdit(centralwidget);
        age->setObjectName(QString::fromUtf8("age"));
        age->setGeometry(QRect(220, 470, 201, 31));
        score = new QTextEdit(centralwidget);
        score->setObjectName(QString::fromUtf8("score"));
        score->setGeometry(QRect(220, 520, 201, 31));
        label_3 = new QLabel(centralwidget);
        label_3->setObjectName(QString::fromUtf8("label_3"));
        label_3->setGeometry(QRect(110, 310, 81, 41));
        label_3->setStyleSheet(QString::fromUtf8("font: 18pt \"Agency FB\";"));
        label_4 = new QLabel(centralwidget);
        label_4->setObjectName(QString::fromUtf8("label_4"));
        label_4->setGeometry(QRect(110, 360, 81, 41));
        label_4->setStyleSheet(QString::fromUtf8("font: 18pt \"Agency FB\";"));
        label_5 = new QLabel(centralwidget);
        label_5->setObjectName(QString::fromUtf8("label_5"));
        label_5->setGeometry(QRect(110, 410, 81, 41));
        label_5->setStyleSheet(QString::fromUtf8("font: 18pt \"Agency FB\";"));
        label_6 = new QLabel(centralwidget);
        label_6->setObjectName(QString::fromUtf8("label_6"));
        label_6->setGeometry(QRect(110, 460, 81, 41));
        label_6->setStyleSheet(QString::fromUtf8("font: 18pt \"Agency FB\";"));
        label_7 = new QLabel(centralwidget);
        label_7->setObjectName(QString::fromUtf8("label_7"));
        label_7->setGeometry(QRect(30, 510, 161, 41));
        label_7->setStyleSheet(QString::fromUtf8("font: 18pt \"Agency FB\";"));
        addButton = new QPushButton(centralwidget);
        addButton->setObjectName(QString::fromUtf8("addButton"));
        addButton->setGeometry(QRect(90, 220, 111, 41));
        addButton->setStyleSheet(QString::fromUtf8("font: 14pt \"Agency FB\";\n"
"font: 16pt \"Agency FB\";"));
        deleteButton = new QPushButton(centralwidget);
        deleteButton->setObjectName(QString::fromUtf8("deleteButton"));
        deleteButton->setGeometry(QRect(250, 220, 111, 41));
        deleteButton->setStyleSheet(QString::fromUtf8("font: 20pt \"Agency FB\";\n"
"color: rgb(255, 16, 40);\n"
"font: 16pt \"Agency FB\";"));
        byId = new QRadioButton(centralwidget);
        byId->setObjectName(QString::fromUtf8("byId"));
        byId->setGeometry(QRect(490, 97, 91, 31));
        byName = new QRadioButton(centralwidget);
        byName->setObjectName(QString::fromUtf8("byName"));
        byName->setGeometry(QRect(570, 97, 91, 31));
        label_2 = new QLabel(centralwidget);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setGeometry(QRect(480, 50, 221, 41));
        showPutton = new QPushButton(centralwidget);
        showPutton->setObjectName(QString::fromUtf8("showPutton"));
        showPutton->setGeometry(QRect(490, 350, 211, 101));
        label_8 = new QLabel(centralwidget);
        label_8->setObjectName(QString::fromUtf8("label_8"));
        label_8->setGeometry(QRect(30, 570, 161, 41));
        label_8->setStyleSheet(QString::fromUtf8("font: 18pt \"Agency FB\";"));
        score_2 = new QTextEdit(centralwidget);
        score_2->setObjectName(QString::fromUtf8("score_2"));
        score_2->setGeometry(QRect(220, 580, 201, 31));
        label_9 = new QLabel(centralwidget);
        label_9->setObjectName(QString::fromUtf8("label_9"));
        label_9->setGeometry(QRect(30, 630, 161, 41));
        label_9->setStyleSheet(QString::fromUtf8("font: 18pt \"Agency FB\";"));
        score_3 = new QTextEdit(centralwidget);
        score_3->setObjectName(QString::fromUtf8("score_3"));
        score_3->setGeometry(QRect(220, 640, 201, 31));
        label_10 = new QLabel(centralwidget);
        label_10->setObjectName(QString::fromUtf8("label_10"));
        label_10->setGeometry(QRect(30, 690, 161, 41));
        label_10->setStyleSheet(QString::fromUtf8("font: 18pt \"Agency FB\";"));
        score_4 = new QTextEdit(centralwidget);
        score_4->setObjectName(QString::fromUtf8("score_4"));
        score_4->setGeometry(QRect(220, 700, 201, 31));
        label_11 = new QLabel(centralwidget);
        label_11->setObjectName(QString::fromUtf8("label_11"));
        label_11->setGeometry(QRect(50, 750, 131, 41));
        label_11->setStyleSheet(QString::fromUtf8("font: 18pt \"Agency FB\";"));
        score_5 = new QTextEdit(centralwidget);
        score_5->setObjectName(QString::fromUtf8("score_5"));
        score_5->setGeometry(QRect(220, 760, 201, 31));
        time = new QDateTimeEdit(centralwidget);
        time->setObjectName(QString::fromUtf8("time"));
        time->setGeometry(QRect(100, 130, 194, 22));
        LoginedWindow->setCentralWidget(centralwidget);
        menubar = new QMenuBar(LoginedWindow);
        menubar->setObjectName(QString::fromUtf8("menubar"));
        menubar->setGeometry(QRect(0, 0, 780, 21));
        LoginedWindow->setMenuBar(menubar);
        statusbar = new QStatusBar(LoginedWindow);
        statusbar->setObjectName(QString::fromUtf8("statusbar"));
        LoginedWindow->setStatusBar(statusbar);
        toolBar = new QToolBar(LoginedWindow);
        toolBar->setObjectName(QString::fromUtf8("toolBar"));
        LoginedWindow->addToolBar(Qt::TopToolBarArea, toolBar);

        retranslateUi(LoginedWindow);

        QMetaObject::connectSlotsByName(LoginedWindow);
    } // setupUi

    void retranslateUi(QMainWindow *LoginedWindow)
    {
        LoginedWindow->setWindowTitle(QCoreApplication::translate("LoginedWindow", "MainWindow", nullptr));
        label->setText(QCoreApplication::translate("LoginedWindow", "\345\255\246\347\224\237\347\256\241\347\220\206\347\263\273\347\273\237", nullptr));
        pushButton->setText(QCoreApplication::translate("LoginedWindow", "\346\220\234\347\264\242", nullptr));
        update_button->setText(QCoreApplication::translate("LoginedWindow", "\344\277\256\346\224\271", nullptr));
        label_3->setText(QCoreApplication::translate("LoginedWindow", "\345\247\223\345\220\215:", nullptr));
        label_4->setText(QCoreApplication::translate("LoginedWindow", "\346\200\247\345\210\253:", nullptr));
        label_5->setText(QCoreApplication::translate("LoginedWindow", "\345\255\246\345\217\267\357\274\232", nullptr));
        label_6->setText(QCoreApplication::translate("LoginedWindow", "\345\271\264\351\276\204\357\274\232", nullptr));
        label_7->setText(QCoreApplication::translate("LoginedWindow", "\350\257\276\347\250\213A\346\210\220\347\273\251\357\274\232", nullptr));
        addButton->setText(QCoreApplication::translate("LoginedWindow", "\346\267\273\345\212\240", nullptr));
        deleteButton->setText(QCoreApplication::translate("LoginedWindow", "\345\210\240\351\231\244", nullptr));
        byId->setText(QCoreApplication::translate("LoginedWindow", "\345\255\246\345\217\267", nullptr));
        byName->setText(QCoreApplication::translate("LoginedWindow", "\345\247\223\345\220\215", nullptr));
        label_2->setText(QCoreApplication::translate("LoginedWindow", "\344\270\215\351\200\211\351\273\230\350\256\244\344\270\272\346\214\211\345\255\246\345\217\267\346\220\234\347\264\242", nullptr));
        showPutton->setText(QCoreApplication::translate("LoginedWindow", "\346\237\245\347\234\213\345\255\246\347\224\237\346\210\220\347\273\251\346\216\222\345\220\215\345\215\225", nullptr));
        label_8->setText(QCoreApplication::translate("LoginedWindow", "\350\257\276\347\250\213B\346\210\220\347\273\251\357\274\232", nullptr));
        label_9->setText(QCoreApplication::translate("LoginedWindow", "\350\257\276\347\250\213C\346\210\220\347\273\251\357\274\232", nullptr));
        label_10->setText(QCoreApplication::translate("LoginedWindow", "\350\257\276\347\250\213D\346\210\220\347\273\251\357\274\232", nullptr));
        label_11->setText(QCoreApplication::translate("LoginedWindow", "\346\200\273\346\210\220\347\273\251\357\274\232", nullptr));
        toolBar->setWindowTitle(QCoreApplication::translate("LoginedWindow", "toolBar", nullptr));
    } // retranslateUi

};

namespace Ui {
    class LoginedWindow: public Ui_LoginedWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_LOGINEDWINDOW_H
