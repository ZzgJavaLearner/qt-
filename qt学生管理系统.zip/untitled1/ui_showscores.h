/********************************************************************************
** Form generated from reading UI file 'showscores.ui'
**
** Created by: Qt User Interface Compiler version 5.14.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_SHOWSCORES_H
#define UI_SHOWSCORES_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QDialogButtonBox>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QTableWidget>

QT_BEGIN_NAMESPACE

class Ui_showScores
{
public:
    QDialogButtonBox *buttonBox;
    QTableWidget *score_paihang;
    QLabel *label;

    void setupUi(QDialog *showScores)
    {
        if (showScores->objectName().isEmpty())
            showScores->setObjectName(QString::fromUtf8("showScores"));
        showScores->resize(1290, 602);
        buttonBox = new QDialogButtonBox(showScores);
        buttonBox->setObjectName(QString::fromUtf8("buttonBox"));
        buttonBox->setGeometry(QRect(480, 540, 341, 32));
        buttonBox->setOrientation(Qt::Horizontal);
        buttonBox->setStandardButtons(QDialogButtonBox::Cancel|QDialogButtonBox::Ok);
        score_paihang = new QTableWidget(showScores);
        score_paihang->setObjectName(QString::fromUtf8("score_paihang"));
        score_paihang->setGeometry(QRect(20, 60, 1171, 441));
        label = new QLabel(showScores);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(180, 20, 201, 31));

        retranslateUi(showScores);
        QObject::connect(buttonBox, SIGNAL(accepted()), showScores, SLOT(accept()));
        QObject::connect(buttonBox, SIGNAL(rejected()), showScores, SLOT(reject()));

        QMetaObject::connectSlotsByName(showScores);
    } // setupUi

    void retranslateUi(QDialog *showScores)
    {
        showScores->setWindowTitle(QCoreApplication::translate("showScores", "Dialog", nullptr));
        label->setText(QCoreApplication::translate("showScores", "\346\211\200\346\234\211\345\255\246\347\224\237\346\210\220\347\273\251\346\216\222\350\241\214", nullptr));
    } // retranslateUi

};

namespace Ui {
    class showScores: public Ui_showScores {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_SHOWSCORES_H
